# Sonam AI Voice Assistant

Starter Android project for Sonam.

Foundation:
- Voice input
- Hindi speech recognition
- Android Text-to-Speech
- Animated neon UI
- Basic app/URL commands
- Gemini API key stored outside source code
- GitHub Actions debug APK build
- Structure ready for future modules

Note: Android and WhatsApp security restrictions mean some automation needs user permission/confirmation.
