package com.sonam.assistant

import android.Manifest
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.util.Locale

class MainActivity : AppCompatActivity(), TextToSpeech.OnInitListener {
    private lateinit var status: TextView
    private lateinit var chat: TextView
    private lateinit var tts: TextToSpeech
    private var recognizer: SpeechRecognizer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        status = findViewById(R.id.status)
        chat = findViewById(R.id.chat)
        tts = TextToSpeech(this, this)
        findViewById<Button>(R.id.micButton).setOnClickListener { startListening() }
        findViewById<Button>(R.id.settingsButton).setOnClickListener { showApiKeyDialog() }

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), 100)
        }
    }

    private fun startListening() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            Toast.makeText(this, "Speech recognition available nahi hai.", Toast.LENGTH_LONG).show()
            return
        }
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) { status.text = "Listening..." }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() { status.text = "Thinking..." }
            override fun onError(error: Int) {
                status.text = "Ready"; speak("Sorry, main samajh nahi paayi.")
            }
            override fun onResults(results: Bundle?) {
                val text = results?.getStringArrayList(
                    SpeechRecognizer.RESULTS_RECOGNITION
                )?.firstOrNull().orEmpty()
                if (text.isNotBlank()) handleCommand(text) else status.text = "Ready"
            }
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
        }
        recognizer?.startListening(intent)
    }

    private fun handleCommand(command: String) {
        chat.append("\nYou: $command\n")
        val c = command.lowercase(Locale.getDefault())
        when {
            c.contains("whatsapp") -> {
                chat.append("Sonam: WhatsApp open kar rahi hoon.\n")
                speak("WhatsApp khol rahi hoon.")
                packageManager.getLaunchIntentForPackage("com.whatsapp")?.let { startActivity(it) }
                    ?: Toast.makeText(this, "WhatsApp installed nahi hai.", Toast.LENGTH_SHORT).show()
            }
            c.contains("youtube") -> openUrl("https://www.youtube.com")
            c.contains("google") -> openUrl("https://www.google.com")
            c.contains("settings") -> startActivity(Intent(android.provider.Settings.ACTION_SETTINGS))
            else -> {
                val reply = "Maine suna: $command. Gemini integration next module mein add ki ja sakti hai."
                chat.append("Sonam: $reply\n"); speak(reply)
            }
        }
        status.text = "Ready"
    }

    private fun openUrl(url: String) = startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))

    private fun showApiKeyDialog() {
        val input = EditText(this).apply { hint = "Gemini API key"; inputType = 0x00000081 }
        val prefs = getSharedPreferences("sonam", MODE_PRIVATE)
        input.setText(prefs.getString("gemini_key", ""))
        AlertDialog.Builder(this)
            .setTitle("Gemini API Key")
            .setMessage("Key source code mein hard-code nahi ki gayi. Ye device par save hogi.")
            .setView(input)
            .setPositiveButton("Save") { _, _ ->
                prefs.edit().putString("gemini_key", input.text.toString().trim()).apply()
                Toast.makeText(this, "API key saved.", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Cancel", null).show()
    }

    private fun speak(text: String) {
        if (::tts.isInitialized) tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "sonam")
    }
    override fun onInit(statusCode: Int) {
        if (statusCode == TextToSpeech.SUCCESS) tts.language = Locale("hi", "IN")
    }
    override fun onDestroy() {
        recognizer?.destroy(); tts.shutdown(); super.onDestroy()
    }
}
