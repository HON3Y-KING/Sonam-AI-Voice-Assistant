package com.sonam.assistant
import android.content.Context
import android.graphics.*
import android.view.View
import kotlin.math.sin

class NeonView(context: Context) : View(context) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var t = 0f
    init { setLayerType(View.LAYER_TYPE_SOFTWARE, null) }

    override fun onDraw(canvas: Canvas) {
        canvas.drawColor(Color.rgb(5, 5, 9))
        val cx = width / 2f
        val cy = height / 2f
        val pulse = 1f + 0.06f * sin(t.toDouble()).toFloat()
        val radius = minOf(width, height) * 0.24f * pulse
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 10f
        paint.color = Color.rgb(80, 180, 255)
        paint.setShadowLayer(45f, 0f, 0f, Color.rgb(0, 170, 255))
        canvas.drawCircle(cx, cy, radius, paint)
        paint.strokeWidth = 3f
        paint.color = Color.rgb(210, 90, 255)
        paint.setShadowLayer(28f, 0f, 0f, Color.rgb(210, 90, 255))
        canvas.drawCircle(cx, cy, radius * 1.18f, paint)
        paint.clearShadowLayer()
        t += 0.045f
        postInvalidateOnAnimation()
    }
}
