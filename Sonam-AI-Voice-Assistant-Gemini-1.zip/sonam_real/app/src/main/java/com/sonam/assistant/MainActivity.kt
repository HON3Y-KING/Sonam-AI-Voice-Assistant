package com.sonam.assistant

import android.Manifest
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import kotlin.concurrent.thread

class MainActivity : AppCompatActivity(), TextToSpeech.OnInitListener {
    private lateinit var status: TextView
    private lateinit var chat: TextView
    private lateinit var tts: TextToSpeech
    private var recognizer: SpeechRecognizer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        status = findViewById(R.id.status)
        chat = findViewById(R.id.chat)
        tts = TextToSpeech(this, this)
        findViewById<Button>(R.id.micButton).setOnClickListener { startListening() }
        findViewById<Button>(R.id.settingsButton).setOnClickListener { showApiKeyDialog() }

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), 100)
        }
    }

    private fun startListening() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            Toast.makeText(this, "Speech recognition available nahi hai.", Toast.LENGTH_LONG).show()
            return
        }
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) { status.text = "Listening..." }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() { status.text = "Thinking..." }
            override fun onError(error: Int) {
                status.text = "Ready"
                speak("Sorry, main samajh nahi paayi.")
            }
            override fun onResults(results: Bundle?) {
                val text = results?.getStringArrayList(
                    SpeechRecognizer.RESULTS_RECOGNITION
                )?.firstOrNull().orEmpty()
                if (text.isNotBlank()) handleCommand(text) else status.text = "Ready"
            }
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
        }
        recognizer?.startListening(intent)
    }

    private fun handleCommand(command: String) {
        chat.append("\nYou: $command\n")
        val c = command.lowercase(Locale.getDefault())
        when {
            c.contains("whatsapp") -> {
                chat.append("Sonam: WhatsApp open kar rahi hoon.\n")
                speak("WhatsApp khol rahi hoon.")
                packageManager.getLaunchIntentForPackage("com.whatsapp")?.let { startActivity(it) }
                    ?: Toast.makeText(this, "WhatsApp installed nahi hai.", Toast.LENGTH_SHORT).show()
                status.text = "Ready"
            }
            c.contains("youtube") -> { openUrl("https://www.youtube.com"); status.text = "Ready" }
            c.contains("google") -> { openUrl("https://www.google.com"); status.text = "Ready" }
            c.contains("settings") -> {
                startActivity(Intent(android.provider.Settings.ACTION_SETTINGS)); status.text = "Ready"
            }
            else -> askGemini(command)
        }
    }

    private fun askGemini(command: String) {
        val key = getSharedPreferences("sonam", MODE_PRIVATE)
            .getString("gemini_key", "")?.trim().orEmpty()
        if (key.isBlank()) {
            chat.append("Sonam: Pehle Settings mein Gemini API key save karo.\n")
            speak("Pehle Settings mein Gemini API key save karo.")
            status.text = "Ready"
            return
        }

        status.text = "Gemini thinking..."
        thread {
            try {
                val reply = callGemini(key, command)
                runOnUiThread {
                    chat.append("Sonam: $reply\n")
                    speak(reply)
                    status.text = "Ready"
                }
            } catch (e: Exception) {
                runOnUiThread {
                    val msg = "Gemini se response nahi mila. Internet aur API key check karo."
                    chat.append("Sonam: $msg\n")
                    speak(msg)
                    status.text = "Ready"
                }
            }
        }
    }

    private fun callGemini(apiKey: String, userText: String): String {
        val url = URL("https://generativelanguage.googleapis.com/v1beta/models/gemini-3.8-flash:generateContent")
        val connection = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 20000
            readTimeout = 30000
            doOutput = true
            setRequestProperty("Content-Type", "application/json")
            setRequestProperty("x-goog-api-key", apiKey)
        }

        val body = JSONObject().apply {
            put("contents", org.json.JSONArray().put(
                JSONObject().apply {
                    put("parts", org.json.JSONArray().put(
                        JSONObject().put(
                            "text",
                            "You are Sonam, a friendly Hindi/Hinglish Android voice assistant. " +
                                "Call the user Boss. Keep answers natural and reasonably short for voice. " +
                                "User says: $userText"
                        )
                    ))
                }
            ))
        }

        OutputStreamWriter(connection.outputStream).use { it.write(body.toString()) }
        val code = connection.responseCode
        val stream = if (code in 200..299) connection.inputStream else connection.errorStream
        val response = BufferedReader(InputStreamReader(stream)).use { it.readText() }
        connection.disconnect()

        if (code !in 200..299) throw IllegalStateException("HTTP $code")
        val json = JSONObject(response)
        return json.getJSONArray("candidates")
            .getJSONObject(0)
            .getJSONObject("content")
            .getJSONArray("parts")
            .getJSONObject(0)
            .getString("text")
            .trim()
    }

    private fun openUrl(url: String) = startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))

    private fun showApiKeyDialog() {
        val input = EditText(this).apply {
            hint = "Gemini API key"
            inputType = 0x00000081
        }
        val prefs = getSharedPreferences("sonam", MODE_PRIVATE)
        input.setText(prefs.getString("gemini_key", ""))
        AlertDialog.Builder(this)
            .setTitle("Gemini API Key")
            .setMessage("Key source code mein hard-code nahi ki gayi. Ye device par save hogi.")
            .setView(input)
            .setPositiveButton("Save") { _, _ ->
                prefs.edit().putString("gemini_key", input.text.toString().trim()).apply()
                Toast.makeText(this, "API key saved.", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Cancel", null).show()
    }

    private fun speak(text: String) {
        if (::tts.isInitialized) tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "sonam")
    }

    override fun onInit(statusCode: Int) {
        if (statusCode == TextToSpeech.SUCCESS) tts.language = Locale("hi", "IN")
    }

    override fun onDestroy() {
        recognizer?.destroy()
        tts.shutdown()
        super.onDestroy()
    }
}
