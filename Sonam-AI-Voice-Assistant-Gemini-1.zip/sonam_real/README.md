# Sonam AI Voice Assistant

This version adds Gemini text responses to the existing voice assistant foundation.

## Setup
1. Build the APK with GitHub Actions.
2. Install the APK.
3. Open **Settings / Gemini API Key** inside Sonam and paste your own Gemini API key.
4. Do not commit the API key to GitHub.

The app sends Gemini requests directly from the device. This is suitable for a personal prototype, but a production app should use a backend/proxy so the API key is not exposed in the distributed APK.
